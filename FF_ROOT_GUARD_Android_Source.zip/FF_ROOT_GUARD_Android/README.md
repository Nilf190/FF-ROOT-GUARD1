# FF ROOT GUARD — Android APK project

A small offline Android WebView dashboard for APatch users.

## Features
- Cyberpunk-style local dashboard
- Basic app/device display information
- Manual APatch/root safety checklist
- No Internet permission, no shell execution, no root-hiding, no game interaction

## Build an APK
1. Install Android Studio (Giraffe or newer) on a computer.
2. Open this `FF_ROOT_GUARD_Android` folder in Android Studio.
3. Let Gradle sync. Use JDK 17 if Android Studio asks.
4. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. When the build finishes, choose **locate**. The debug APK is normally at:
   `app/build/outputs/apk/debug/app-debug.apk`
6. Transfer the APK to your Android phone and install it. If Android asks, allow installation from that file manager for this install.

## Notes
- `minSdk 23` (Android 6.0+); compile SDK 35.
- Package: `com.ffrootguard`
- App label: `FF ROOT GUARD`
- This source project is provided; a compiled/signed APK is not included.
- This is not an anti-ban guarantee or anti-cheat bypass. It does not read APatch internals, run root commands, hide root, or alter Free Fire.
