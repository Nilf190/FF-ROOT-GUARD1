package com.ffrootguard;

final class Dashboard {
    private Dashboard() {}
    static final String HTML = """
<!doctype html><html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="color-scheme" content="dark">
<style>
:root{--bg:#080b13;--panel:#111a29;--line:#263851;--cyan:#00e5ff;--pink:#ff2d75;--green:#53ffb0;--muted:#91a5bd;--white:#eaf6ff}
*{box-sizing:border-box}body{margin:0;padding:18px;background:radial-gradient(ellipse at 10% 0%,#10283b,transparent 42%),radial-gradient(ellipse at 100% 25%,#29152e,transparent 36%),var(--bg);color:var(--white);font:14px/1.5 system-ui, sans-serif}
main{max-width:760px;margin:auto}.top{display:flex;justify-content:space-between;align-items:center;margin:4px 0 20px}.brand{font-size:19px;font-weight:900;letter-spacing:2px}.brand b{color:var(--cyan)}.tag{font-size:10px;color:var(--cyan);border:1px solid #31506b;border-radius:20px;padding:5px 8px}
.hero,.card{background:linear-gradient(145deg,#121d2df2,#0b111df5);border:1px solid var(--line);border-radius:15px;padding:18px;margin-bottom:13px;box-shadow:0 12px 30px #0005}
.kicker{font-size:10px;letter-spacing:2px;color:var(--muted)}h1{font-size:32px;color:var(--cyan);margin:6px 0;text-shadow:0 0 18px #00e5ff55}.muted,.small{color:var(--muted)}.small{font-size:12px}.grid{display:grid;grid-template-columns:1fr 1fr;gap:13px}.card h2{font-size:12px;letter-spacing:1px;color:var(--cyan);margin:0 0 10px}.line{display:flex;justify-content:space-between;gap:8px;padding:8px 0;border-bottom:1px solid #ffffff10}.line:last-child{border:0}.pill{font-size:10px;border:1px solid #81642c;color:#ffd27a;border-radius:20px;padding:2px 7px}.ok{color:var(--green);border-color:#286d56}.checks label{display:flex;gap:9px;padding:8px 0;border-bottom:1px solid #ffffff10}.checks input{accent-color:var(--cyan);margin-top:4px}button{background:#092330;border:1px solid #24546a;color:var(--cyan);padding:10px 13px;border-radius:8px;font-weight:700;margin:12px 6px 0 0}.warn{margin-top:12px;border-left:3px solid var(--pink);background:#ff2d7510;padding:10px;border-radius:6px;font-size:12px;color:#f4c6d5}.foot{text-align:center;color:#60748d;font-size:10px;letter-spacing:1px;margin:18px}
@media(max-width:560px){.grid{grid-template-columns:1fr}body{padding:13px}}
</style></head><body><main>
<div class="top"><div class="brand">FF <b>ROOT</b> GUARD</div><div class="tag">APATCH // LOCAL</div></div>
<section class="hero"><div class="kicker">DEVICE SAFETY DASHBOARD</div><h1 id="state">STATUS: UNVERIFIED</h1>
<div class="muted">Local device-safety checklist for APatch users. No game-server connection and no anti-cheat bypass.</div>
<button onclick="refreshInfo()">REFRESH DEVICE INFO</button><button onclick="resetChecks()">RESET CHECKLIST</button></section>
<div class="grid">
<section class="card"><h2>DEVICE SNAPSHOT</h2>
<div class="line"><span>Android</span><b id="android">Checking…</b></div>
<div class="line"><span>App version</span><b>1.0</b></div>
<div class="line"><span>Screen</span><b id="screen">—</b></div>
<p class="small">This app only displays basic app/device information. It cannot inspect protected system properties.</p></section>
<section class="card"><h2>APATCH STATUS</h2>
<div class="line"><span>Root manager</span><b>APatch</b></div>
<div class="line"><span>Root access</span><span class="pill">MANUAL CHECK</span></div>
<div class="line"><span>Modules</span><span class="pill">NOT READ</span></div>
<div class="line"><span>SELinux</span><span class="pill">NOT READ</span></div>
<p class="small">Verify root and module state inside the APatch app itself.</p></section>
<section class="card"><h2>SAFETY CHECKLIST</h2><div class="checks" id="checks">
<label><input type="checkbox"> APatch opens and reports expected status.</label>
<label><input type="checkbox"> I understand each installed module.</label>
<label><input type="checkbox"> Unstable or unknown modules are disabled.</label>
<label><input type="checkbox"> I have a recovery / boot-image backup.</label>
<label><input type="checkbox"> I use the official, unmodified game client.</label>
</div><p class="small" id="progress">0 of 5 complete</p></section>
<section class="card"><h2>SAFE USE</h2>
<div class="line"><span>Official game client</span><span class="pill ok">RECOMMENDED</span></div>
<div class="line"><span>Unknown modules</span><span class="pill">REVIEW FIRST</span></div>
<div class="line"><span>Anti-cheat evasion</span><span class="pill">NOT INCLUDED</span></div>
<p class="small">Avoid modified APKs, memory edits, spoofing, or anti-cheat evasion. These may risk your account and device.</p></section>
</div>
<div class="warn"><b>Important:</b> No tool can guarantee protection from account bans. This app does not hide root, change APatch settings, execute shell commands, inspect Free Fire, or modify game behaviour.</div>
<div class="foot">FF ROOT GUARD • OFFLINE • NO NETWORK PERMISSION</div>
</main><script>
function refreshInfo(){document.getElementById('android').textContent='Android WebView';document.getElementById('screen').textContent=screen.width+' × '+screen.height;}
function progress(){let a=[...document.querySelectorAll('#checks input')],n=a.filter(x=>x.checked).length;document.getElementById('progress').textContent=n+' of '+a.length+' complete';document.getElementById('state').textContent=n===a.length?'CHECKLIST COMPLETE':'STATUS: UNVERIFIED';}
function resetChecks(){document.querySelectorAll('#checks input').forEach(x=>x.checked=false);progress();}
document.querySelectorAll('#checks input').forEach(x=>x.addEventListener('change',progress));refreshInfo();progress();
</script></body></html>
""";
}
